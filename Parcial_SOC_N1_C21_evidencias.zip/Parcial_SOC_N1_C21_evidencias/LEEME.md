# Paquete de evidencias – Parcial SOC N1 – Caso C21 (ERP Pyme S.A.S.)

Autores: Brayan Javier Becerra Sandoval y Christian Julian Peña Mantilla · Fecha de empaquetado: 22/10/2026
Entorno: laboratorio aislado (VirtualBox, red host-only). Todos los datos son ficticios.

## Estructura
| Carpeta | Contenido |
|---|---|
| F00_Alcance_y_etica | Carta de autorización (PENDIENTE FIRMAS) |
| F01_Arquitectura | Captura de VM de VirtualBox y diagrama real del laboratorio |
| F02_Wazuh | 2 capturas (instalador y dashboard), reglas, decoder, FIM, active response, scripts |
| F03_Kaspersky | 5 capturas de KES 14.1.0.423 administrado desde la nube, políticas y esqueleto CEF |
| F04_GLPI | 18 capturas de instalación y configuración, diagrama y script de respaldo |
| F05_NGFW | Las 3 cotizaciones reales (PENDIENTES), plantilla de solicitud y gráficos de referencia |
| F06_Procesos_SOC_N1 | Capturas de tickets, transcripción de la lista, flujo de atención |
| F07_Presupuesto | Presupuesto estimado (CAPEX/OPEX/TCO) |
| MANIFIESTO_SHA256.csv | Huella SHA-256 de cada archivo |

## Estado honesto de la evidencia
- Evidenciado: instalación de Wazuh (servidor), KES conectado a consola en la nube, GLPI local con entidades, perfiles, grupos,
  8 usuarios, 6 categorías y 6 tickets.
- NO evidenciado (ver LISTA_VERIFICACION.md): agentes Wazuh, FIM/SCA/vulnerabilidades con resultados, reglas con wazuh-logtest,
  active response, EICAR, envío Kaspersky→Wazuh, HTTPS/SLA/KB/respaldo de GLPI, cotizaciones reales.
- Los tickets son de alertas SIMULADAS. Las capturas muestran fecha y hora del equipo; los hostnames son los de las VM del laboratorio
  (WIN10-KASPERSKY-01, SRV-C21-WAZUH). No se incluyen contraseñas, llaves ni tokens.
