#!/usr/bin/env bash
# Respaldo diario de GLPI (objetivo de diseño, cron 02:00 America/Bogota). La clave/credencial de BD va en ~/.my.cnf, NO aquí.
set -euo pipefail
D=$(date +%F)
mysqldump --single-transaction glpi | gzip > /backup/glpi_$D.sql.gz
tar czf /backup/glpi_files_$D.tgz /var/www/glpi/files /var/www/glpi/config
gpg --encrypt --recipient soc@erppyme.example /backup/glpi_*_$D.*
