#!/usr/bin/env bash
# Instalación todo-en-uno y endurecimiento (ejemplos; NO incluir contraseñas generadas por el instalador)
sudo apt update && sudo apt -y upgrade
curl -sO https://packages.wazuh.com/4.14/wazuh-install.sh
sudo bash ./wazuh-install.sh -a

# Grupos de agentes
sudo /var/ossec/bin/agent_groups -a -g windows-oficina -q
sudo /var/ossec/bin/agent_groups -a -g linux-servidores -q

# Firewall del servidor (red host-only del laboratorio)
sudo ufw default deny incoming
sudo ufw allow from 192.168.56.0/24 to any port 22 proto tcp
sudo ufw allow from 192.168.56.0/24 to any port 443 proto tcp
sudo ufw allow from 192.168.56.0/24 to any port 1514 proto tcp
sudo ufw allow from 192.168.56.0/24 to any port 1515 proto tcp
sudo ufw enable

# Agente Linux (ejemplo): WAZUH_MANAGER='192.168.56.10' WAZUH_AGENT_GROUP='linux-servidores' apt install wazuh-agent
# Agente Windows (PowerShell admin): msiexec.exe /i wazuh-agent.msi /q WAZUH_MANAGER='192.168.56.10' WAZUH_AGENT_GROUP='windows-oficina'
